package com.sena.servicesecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.DTO.IEmployedDto;
import com.sena.servicesecurity.Entity.Employed;


@Repository
public interface IEmployedRepository extends IBaseRepository<Employed, Long> {

	@Query(value = "SELECT " + 
            "    e.id, " + 
            "    e.created_at, " + 
            "    e.created_by, " + 
            "    e.deleted_at, " + 
            "    e.deleted_by, " + 
            "    e.state, " + 
            "    e.updated_at, " + 
            "    e.updated_by, " + 
            "    e.salary, " + 
            "    e.person_id, " + 
            "    e.company_id, " +
            "    e.position_id " +
            "FROM " + 
            "    service_security.employed e", 
    nativeQuery = true)
List<IEmployedDto> getList();


}