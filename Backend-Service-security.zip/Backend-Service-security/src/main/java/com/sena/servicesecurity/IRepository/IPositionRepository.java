package com.sena.servicesecurity.IRepository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.sena.servicesecurity.DTO.IPositionDto;
import com.sena.servicesecurity.Entity.Position;

@Repository
public interface IPositionRepository extends IBaseRepository<Position, Long> {
	
	@Query(value = "SELECT " + 
            "    p.id, " + 
            "    p.created_at, " + 
            "    p.created_by, " + 
            "    p.deleted_at, " + 
            "    p.deleted_by, " + 
            "    p.state, " + 
            "    p.updated_at, " + 
            "    p.updated_by, " +
            "    p.name, " +
            "    p.code " + 
            "FROM " + 
            "    service_security.position p", 
    nativeQuery = true)
List<IPositionDto> getListPositions();

}
