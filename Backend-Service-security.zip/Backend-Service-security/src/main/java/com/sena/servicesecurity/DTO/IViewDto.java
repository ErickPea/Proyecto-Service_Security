package com.sena.servicesecurity.DTO;

public interface IViewDto extends IGenericDto {

	String getModule();

	String getDescription();

	String getName();

	String getRoute();

}
