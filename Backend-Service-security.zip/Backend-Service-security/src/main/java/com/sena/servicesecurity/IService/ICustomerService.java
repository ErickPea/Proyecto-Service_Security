package com.sena.servicesecurity.IService;

import com.sena.servicesecurity.Entity.Customer;
import com.sena.servicesecurity.Entity.Person;

public interface ICustomerService extends IBaseService<Customer>{
	
   public String GenerateCodeCustomer(long idPerson) throws Exception ;
	
	public void update(Long id, Customer entity) throws Exception;

	public Customer savePersonCustomer(Person entity) throws Exception;

}
