package com.sena.servicesecurity.IService;

import com.sena.servicesecurity.Utils.Document_Type;
import com.sena.servicesecurity.Utils.weekdays;

public interface IEnumService {

	Document_Type[] getDocument_Type();
	weekdays[] getWeekdays();
	
}
