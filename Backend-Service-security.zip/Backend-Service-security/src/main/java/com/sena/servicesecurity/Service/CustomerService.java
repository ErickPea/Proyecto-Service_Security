package com.sena.servicesecurity.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.sena.servicesecurity.Entity.Customer;

import com.sena.servicesecurity.Entity.Person;
import com.sena.servicesecurity.IRepository.IBaseRepository;
import com.sena.servicesecurity.IRepository.ICustomerRepository;
import com.sena.servicesecurity.IService.ICustomerService;
import com.sena.servicesecurity.IService.IPersonService;

@Service
public class CustomerService extends ABaseService<Customer> implements ICustomerService{

	@Autowired
	public ICustomerRepository repository;
	@Autowired
	public IPersonService personService;
	
	@Override
	public Customer savePersonCustomer(Person entity) throws Exception {
	    Person person = personService.save(entity);
	    
        Customer entityCustomer = new Customer();
        
	    String codeCustomer =GenerateCodeCustomer(person.getId());
	    
	    entityCustomer.setCode(codeCustomer);
	    entityCustomer.setPerson(person);
	    entityCustomer.setState(true);
	    entityCustomer.setCreatedAt(LocalDateTime.now());
	    entityCustomer.setCreatedBy((long) 1);
	    
	    Customer customer = save(entityCustomer);
	    
	    return customer;
	}
	
	@Override
	protected IBaseRepository<Customer, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}
	
	
	@Override
	public Customer save(Customer entity) throws Exception {
	    try {
	       
    		String codeCustomer = GenerateCodeCustomer(entity.getPerson().getId());
	        entity.setCode(codeCustomer);
	        entity.setCreatedAt(LocalDateTime.now());
	        entity.setCreatedBy((long) 1); // Cuando esté el logging, se debe enviar el ID del usuario con Auth
	        return getRepository().save(entity);
	    } catch (Exception e) {
	        // Captura la excepción
	        throw new Exception("Error al guardar la entidad: " + e.getMessage());
	    }
	}

	
	@Override
	public String GenerateCodeCustomer(long idPerson) throws Exception {
		 	Optional<Person> person = personService.findById(idPerson) ;
	       
		 	if (person == null) {
	            throw new Exception("No se encontro persona con el ID: " + idPerson);
	        }
		 	
		 	String document = person.get().getDocument();
		 	
	        // Obtener los primeros 4 dígitos del documento
	        String documentDigits = document.substring(Math.max(0, document.length() -4));

	        // Obtener el año actual
	        int currentYear = LocalDate.now().getYear();

	        // Combinar los elementos para formar el código
	        String code = currentYear + "-" + person.get().getDocumentType() + "-" + documentDigits;
	        
	        return code;
	}


	@Override
	public void update(Long id, Customer entity) throws Exception {
	    Optional<Customer> op = getRepository().findById(id);

	    if (op.isEmpty()) {
	        throw new Exception("Registro no encontrado");
	    } else if (op.get().getDeletedAt() != null) {
	        throw new Exception("Registro inhabilitado");
	    }

	    Long personId = entity.getPerson().getId();
	    String code = GenerateCodeCustomer(personId);

	    Customer entityUpdate = op.get();

	    String[] ignoreProperties = { "id", "createdAt", "deletedAt", "createdBy", "deletedBy" };
	    BeanUtils.copyProperties(entity, entityUpdate, ignoreProperties);
	    entityUpdate.setCode(code);
	    entityUpdate.setUpdatedAt(LocalDateTime.now());
	    entityUpdate.setUpdatedBy((long) 1); // Cuando esté el logging, se debe enviar el ID del usuario con Auth
	    getRepository().save(entityUpdate);
	}

}
