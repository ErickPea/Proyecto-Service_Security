package com.sena.servicesecurity.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sena.servicesecurity.DTO.IPersonDto;
import com.sena.servicesecurity.Entity.Person;
import com.sena.servicesecurity.IRepository.IBaseRepository;
import com.sena.servicesecurity.IRepository.IPersonRepository;
import com.sena.servicesecurity.IService.IPersonService;

@Service
public class PersonService extends ABaseService<Person> implements IPersonService {

	@Autowired
	private IPersonRepository repository;

	@Override
	public List<IPersonDto> getList() {
		// TODO Auto-generated method stub
		return repository.getList();
	}

	@Override
	protected IBaseRepository<Person, Long> getRepository() {
		// TODO Auto-generated method stub
		return repository;
	}
	
	@Override
	public List<IPersonDto> getTypeDocument(String type) {
		return repository.getTypeDocument(type);
	}


}
